//
//  NotaViewController.swift
//  PS_RM76349_Fernando
//
//  Created by Fernando Carvalho Castro on 02/06/17.
//  Copyright © 2017 Fernando Carvalho Castro. All rights reserved.
//

import UIKit

class NotaViewController: UIViewController {

    
    @IBOutlet weak var txtNome: UITextField!
    @IBOutlet weak var lblNota: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNota.text = "0"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func stepperNotaValueChanged(_ sender: UIStepper) {
        lblNota.text = "\(Int(sender.value))"
    }
    
    
    @IBAction func salvar(_ sender: Any) {
        var nome:String
        var nota:String
        var msg:String
        nome = txtNome.text!
        nota = lblNota.text!
        msg = "Eu \(nome) vou tirar a nota \(nota)."
        
        let alerta = UIAlertController(
            title: "AVISO",
            message: msg,
            preferredStyle: UIAlertControllerStyle.actionSheet)
        
        alerta.addAction(UIAlertAction(
            title: "OK",
            style: UIAlertActionStyle.default,
            handler: nil))
        
        present(alerta, animated: true, completion: nil)
    }
    
    
    @IBAction func fechar(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
