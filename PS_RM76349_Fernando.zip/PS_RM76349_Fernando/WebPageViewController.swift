//
//  WebPageViewController.swift
//  PS_RM76349_Fernando
//
//  Created by Fernando Carvalho Castro on 02/06/17.
//  Copyright © 2017 Fernando Carvalho Castro. All rights reserved.
//

import UIKit

class WebPageViewController: UIViewController, UIWebViewDelegate {

    let URL_PAGINA = "https://www.fiap.com.br"
    
    @IBOutlet weak var paginaWebView: UIWebView!
    
    @IBOutlet weak var carregarActivity: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        paginaWebView.delegate = self
        carregarActivity.startAnimating()
        carregarActivity.hidesWhenStopped = true
        
        let URL_OK = URL(string: URL_PAGINA)
        let request = URLRequest(url: URL_OK!)
        paginaWebView.loadRequest(request)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        let msg = "Erro: \(error.localizedDescription)"
        let alerta = UIAlertController(
            title: "Aviso",
            message: msg,
            preferredStyle: UIAlertControllerStyle.alert)
        alerta.addAction(UIAlertAction(
            title: "OK",
            style: UIAlertActionStyle.default,
            handler: nil))
        
        present(alerta, animated: true, completion: nil)
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        carregarActivity.stopAnimating()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func abrirTelaPorCodigo(_ sender: Any) {
        performSegue(withIdentifier: "telaTurmaSegue", sender: sender)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier=="telaTurmaSegue"){
            let t = segue.destination as! TurmaViewController
            t.msg = "Teste de mensagem entre views"
        }
    }

}
